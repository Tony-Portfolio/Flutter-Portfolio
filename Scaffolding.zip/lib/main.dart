import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:url_launcher/url_launcher.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Hello World',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        appBarTheme: AppBarTheme(
          backgroundColor: Colors.black, // Set navigation bar background color
          iconTheme: IconThemeData(
              color: Colors.white), // Set navigation bar icon color
        ),
      ),
      home: MyHomePage(title: 'Home'),
    );
  }
}

class LinkButtons extends StatelessWidget {
  final String text;
  final String url;
  final String svg;

  const LinkButtons(
      {Key? key, required this.text, required this.url, required this.svg})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
        cursor: SystemMouseCursors.click,
        child: GestureDetector(
            onTap: () async {
              if (await canLaunch(url)) {
                await launch(url);
              } else {
                print("Something went wrong");
              }
            },
            child: Container(
                padding: const EdgeInsets.all(8.0),
                decoration: BoxDecoration(
                  color: Colors.blue,
                  borderRadius: BorderRadius.circular(8.0),
                ),
                child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SvgPicture.asset(
                        svg,
                        height: 24,
                        width: 24,
                        color: Colors.white,
                      ),
                      SizedBox(
                        width: 8,
                      ),
                      Text(text,
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ))
                    ]))));
  }
}

class MyHomePage extends StatelessWidget {
  final String title;

  const MyHomePage({Key? key, required this.title}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        // appBar: AppBar(
        //   title: Text(title, style: const TextStyle(fontSize: 30)),
        //   leading: Padding(
        //     padding: const EdgeInsets.all(8.0),
        //     child: SvgPicture.string(
        //       // Replace the placeholder string with your SVG data
        //       '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" width="14" height="14" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" /></svg>',
        //       color: Colors.white, // Set SVG icon color
        //     ),
        //   ),
        // ),
        body: Align(
      alignment: Alignment.topLeft,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      CircleAvatar(
                        radius: 40,
                        backgroundImage: AssetImage('assets/zero-two.jpg'),
                      ),
                      SizedBox(width: 16),
                      Text(
                        'Hi There 👋',
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 20),
                      ),
                    ],
                  ),
                  SizedBox(
                      height:
                          8), // Optional spacing between profile picture and description
                  Text(
                    'My name is Raka Okto Ramadhan, I was a student in SMK Tamansiswa 2 Jakarta Majoring In Software Engineering',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                  ),
                  SizedBox(
                      height:
                          8), // Optional spacing between description and other content
                  Text(
                    'Im interested in making or designing an application or software',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                  ),
                  SizedBox(
                    height: 8,
                  ),
                  LinkButtons(
                      text: "LinkedIn",
                      url:
                          "https://www.linkedin.com/in/raka-okto-ramadhan-a1578a270/",
                      svg: "assets/linkedin.svg"),
                  SizedBox(
                    height: 8,
                  ),
                  LinkButtons(
                      text: "Github",
                      url: "https://github.com/Tony-Portfolio",
                      svg: "assets/github.svg")
                ],
              )),
        ],
      ),
    ));
  }
}
