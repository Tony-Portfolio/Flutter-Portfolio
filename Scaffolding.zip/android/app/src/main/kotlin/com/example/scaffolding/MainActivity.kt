package com.example.scaffolding

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
